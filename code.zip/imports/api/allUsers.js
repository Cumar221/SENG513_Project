/**
 * Created by Shahab on 4/4/2017.
 */

import { Mongo } from 'meteor/mongo';

export const AllUsers = new Mongo.Collection('allUsers');
