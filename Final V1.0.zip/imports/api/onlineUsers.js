/**
 * Created by Shahab on 4/4/2017.
 */

import { Mongo } from 'meteor/mongo';

export const OnlineUsers = new Mongo.Collection('onlineUsers');
