/**
 * Created by omar on 2017-02-26.
 */
import { Mongo } from 'meteor/mongo';

export const Messages = new Mongo.Collection('messages');